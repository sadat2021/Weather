import React from "react";
import Main from "./page";
import "./styles.scss";

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
